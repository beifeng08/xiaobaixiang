﻿// Copyright (c) 2026 beifeng08
// Licensed under the MIT License. See LICENSE in the project root.

namespace XiaobaiHardwareMonitor.Interop.PowerMonitor;

public enum UsbCmd : byte
{
    CMD_WELCOME,
    CMD_READ_VENDOR_DATA,
    CMD_READ_UID,
    CMD_READ_DEVICE_DATA,
    CMD_READ_SENSOR_VALUES,
    CMD_READ_CONFIG,
    CMD_WRITE_CONFIG,
    CMD_READ_CALIBRATION,
    CMD_WRITE_CALIBRATION,
    CMD_SPI_FLASH_WRITE_PAGE,
    CMD_SPI_FLASH_READ_PAGE,
    CMD_SPI_FLASH_ERASE_SECTOR,
    CMD_SCREEN_CHANGE,
    CMD_READ_BUILD_INFO,
    CMD_CLEAR_FAULTS,
    CMD_RESET = 0xF0,
    CMD_BOOTLOADER = 0xF1,
    CMD_NVM_CONFIG = 0xF2,
    CMD_NOP = 0xFF
}

public enum SensorTs
{
    SENSOR_TS_IN,
    SENSOR_TS_OUT,
    SENSOR_TS3,
    SENSOR_TS4,
}

public enum HpwrCapability : byte
{
    PSU_CAP_600W = 0,
    PSU_CAP_450W = 1,
    PSU_CAP_300W = 2,
    PSU_CAP_150W = 3
}

public enum FanMode : byte
{
    FanModeCurve = 0,
    FanModeFixed = 1
}

public enum TempSource : byte
{
    TempSourceTsIn = 0,
    TempSourceTsOut = 1,
    TempSourceTs1 = 2,
    TempSourceTs2 = 3,
    TempSourceTmax = 4
}

public enum CurrentScale : byte
{
    CurrentScale5A = 0,
    CurrentScale10A = 1,
    CurrentScale15A = 2,
    CurrentScale20A = 3
}

public enum PowerScale : byte
{
    PowerScaleAuto = 0,
    PowerScale300W = 1,
    PowerScale600W = 2
}

public enum Theme : byte
{
    ThemeTg1 = 0,
    ThemeTg2 = 1,
    ThemeTg3 = 2
}

public enum DisplayRotation : byte
{
    DisplayRotation0 = 0,
    DisplayRotation180 = 1
}

public enum TimeoutMode : byte
{
    TimeoutModeStatic = 0,
    TimeoutModeCycle = 1,
    TimeoutModeSleep = 2
}

public enum Screen : byte
{
    ScreenMain = 0,
    ScreenSimple = 1,
    ScreenCurrent = 2,
    ScreenTemp = 3,
    ScreenStatus = 4
}

public enum NVM_CMD : byte
{
    NVM_CMD_NONE,
    NVM_CMD_LOAD,
    NVM_CMD_STORE,
    NVM_CMD_RESET,
    NVM_CMD_LOAD_CAL,
    NVM_CMD_STORE_CAL,
    NVM_CMD_LOAD_CAL_FACTORY,
    NVM_CMD_STORE_CAL_FACTORY,
}

public enum SCREEN_CMD : byte
{
    SCREEN_GOTO_MAIN = 0xE0,
    SCREEN_GOTO_SIMPLE = 0xE1,
    SCREEN_GOTO_CURRENT = 0xE2,
    SCREEN_GOTO_TEMP = 0xE3,
    SCREEN_GOTO_STATUS = 0xE4,
    SCREEN_GOTO_SAME = 0xEF,
    SCREEN_PAUSE_UPDATES = 0xF0,
    SCREEN_RESUME_UPDATES = 0xF1
}

public enum AVG : byte
{
    AVG_22MS,
    AVG_44MS,
    AVG_89MS,
    AVG_177MS,
    AVG_354MS,
    AVG_709MS,
    AVG_1417MS,
}

public enum DISPLAY_INVERSION : byte
{
    DISPLAY_INVERSION_OFF,
    DISPLAY_INVERSION_ON,
    DISPLAY_INVERSION_NUM
}

public enum THEME_BACKGROUND : byte
{
    ThermalGrizzlyOrange = 1,
    ThermalGrizzlyDark = 2,
    Disabled = 255
}

public enum THEME_FAN : byte
{
    ThermalGrizzlyOrange = 0x64, 
    ThermalGrizzlyDark = 0x75, 
    ThermalGrizzlyBlackWhite = 0x98, 
}
