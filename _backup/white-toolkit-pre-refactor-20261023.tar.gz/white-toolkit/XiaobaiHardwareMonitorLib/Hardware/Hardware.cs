﻿// Copyright (c) 2026 beifeng08
// Licensed under the MIT License. See LICENSE in the project root.

using System;
using System.Collections.Generic;
using System.Linq;

namespace XiaobaiHardwareMonitor.Hardware;

public abstract class Hardware : IHardware
{
    protected readonly HashSet<ISensor> _active = new();
    protected readonly string _name;
    protected readonly ISettings _settings;
    private string _customName;

    protected Hardware(string name, Identifier identifier, ISettings settings)
    {
        _settings = settings;
        _name = name;
        Identifier = identifier;
        _customName = settings.GetValue(new Identifier(Identifier, "name").ToString(), name);
    }

    public event HardwareEventHandler Closing;

    public abstract HardwareType HardwareType { get; }

    public Identifier Identifier { get; }

    public string Name
    {
        get { return _customName; }
        set
        {
            _customName = !string.IsNullOrEmpty(value) ? value : _name;

            _settings.SetValue(new Identifier(Identifier, "name").ToString(), _customName);
        }
    }

    public virtual IHardware Parent
    {
        get { return null; }
    }

    public virtual IDictionary<string, string> Properties => new SortedDictionary<string, string>();

    public virtual ISensor[] Sensors
    {
        get { return _active.ToArray(); }
    }

    public virtual IHardware[] SubHardware
    {
        get { return Array.Empty<IHardware>(); }
    }

    public virtual string GetReport()
    {
        return null;
    }

    public abstract void Update();

    public void Accept(IVisitor visitor)
    {
        if (visitor == null)
            throw new ArgumentNullException(nameof(visitor));

        visitor.VisitHardware(this);
    }

    public virtual void Traverse(IVisitor visitor)
    {
        foreach (ISensor sensor in _active)
            sensor.Accept(visitor);
    }

    protected virtual void ActivateSensor(ISensor sensor)
    {
        if (_active.Add(sensor))
            SensorAdded?.Invoke(sensor);
    }

    protected virtual void DeactivateSensor(ISensor sensor)
    {
        if (_active.Remove(sensor))
            SensorRemoved?.Invoke(sensor);
    }

    public virtual void Close()
    {
        Closing?.Invoke(this);
    }

#pragma warning disable 67
    public event SensorEventHandler SensorAdded;

    public event SensorEventHandler SensorRemoved;
#pragma warning restore 67
}
