﻿// Copyright (c) 2026 beifeng08
// Licensed under the MIT License. See LICENSE in the project root.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using XiaobaiHardwareMonitor.Hardware.Battery;
using XiaobaiHardwareMonitor.Hardware.Controller.AeroCool;
using XiaobaiHardwareMonitor.Hardware.Controller.AquaComputer;
using XiaobaiHardwareMonitor.Hardware.Controller.Arctic;
using XiaobaiHardwareMonitor.Hardware.Controller.Heatmaster;
using XiaobaiHardwareMonitor.Hardware.Controller.MSI;
using XiaobaiHardwareMonitor.Hardware.Controller.Nzxt;
using XiaobaiHardwareMonitor.Hardware.Controller.Razer;
using XiaobaiHardwareMonitor.Hardware.Controller.TBalancer;
using XiaobaiHardwareMonitor.Hardware.Cpu;
using XiaobaiHardwareMonitor.Hardware.Gpu;
using XiaobaiHardwareMonitor.Hardware.Memory;
using XiaobaiHardwareMonitor.Hardware.Motherboard;
using XiaobaiHardwareMonitor.Hardware.Network;
using XiaobaiHardwareMonitor.Hardware.PowerMonitor;
using XiaobaiHardwareMonitor.Hardware.Psu.Corsair;
using XiaobaiHardwareMonitor.Hardware.Psu.Msi;
using XiaobaiHardwareMonitor.Hardware.Storage;

namespace XiaobaiHardwareMonitor.Hardware;

public class Computer : IComputer
{
    private readonly List<IGroup> _groups = new();
    private readonly object _lock = new();
    private readonly ISettings _settings;

    private bool _batteryEnabled;
    private bool _controllerEnabled;
    private bool _cpuEnabled;
    private bool _gpuEnabled;
    private bool _powerMonitorEnabled;
    private bool _memoryEnabled;
    private bool _motherboardEnabled;
    private bool _networkEnabled;
    private bool _open;
    private bool _psuEnabled;
    private SMBios _smbios;
    private bool _storageEnabled;

    public Computer()
    {
        _settings = new Settings();
    }

    public Computer(ISettings settings)
    {
        _settings = settings ?? new Settings();
    }

    public event HardwareEventHandler HardwareAdded;

    public event HardwareEventHandler HardwareRemoved;

    public IList<IHardware> Hardware
    {
        get
        {
            lock (_lock)
            {
                List<IHardware> list = new();

                foreach (IGroup group in _groups)
                    list.AddRange(group.Hardware);

                return list;
            }
        }
    }

    public bool IsBatteryEnabled
    {
        get { return _batteryEnabled; }
        set
        {
            if (_open && value != _batteryEnabled)
            {
                if (value)
                {
                    Add(new BatteryGroup(_settings));
                }
                else
                {
                    RemoveType<BatteryGroup>();
                }
            }

            _batteryEnabled = value;
        }
    }

    public bool IsControllerEnabled
    {
        get { return _controllerEnabled; }
        set
        {
            if (_open && value != _controllerEnabled)
            {
                if (value)
                {
                    Add(new TBalancerGroup(_settings));
                    Add(new HeatmasterGroup(_settings));
                    Add(new AquaComputerGroup(_settings));
                    Add(new AeroCoolGroup(_settings));
                    Add(new NzxtGroup(_settings));
                    Add(new RazerGroup(_settings));
                    Add(new ArcticGroup(_settings));
                    Add(new MsiGroup(_settings));
                }
                else
                {
                    RemoveType<TBalancerGroup>();
                    RemoveType<HeatmasterGroup>();
                    RemoveType<AquaComputerGroup>();
                    RemoveType<AeroCoolGroup>();
                    RemoveType<NzxtGroup>();
                    RemoveType<RazerGroup>();
                    RemoveType<ArcticGroup>();
                    RemoveType<MsiGroup>();
                }
            }

            _controllerEnabled = value;
        }
    }

    public bool IsCpuEnabled
    {
        get { return _cpuEnabled; }
        set
        {
            if (_open && value != _cpuEnabled)
            {
                if (value)
                    Add(new CpuGroup(_settings));
                else
                    RemoveType<CpuGroup>();
            }

            _cpuEnabled = value;
        }
    }

    public bool IsGpuEnabled
    {
        get { return _gpuEnabled; }
        set
        {
            if (_open && value != _gpuEnabled)
            {
                if (value)
                {
                    Add(new AmdGpuGroup(_settings));
                    Add(new NvidiaGroup(_settings));

                    if (_cpuEnabled)
                        Add(new IntelGpuGroup(GetIntelCpus(), _settings));
                }
                else
                {
                    RemoveType<AmdGpuGroup>();
                    RemoveType<NvidiaGroup>();
                    RemoveType<IntelGpuGroup>();
                }
            }

            _gpuEnabled = value;
        }
    }

    public bool IsPowerMonitorEnabled
    {
        get { return _powerMonitorEnabled; }
        set
        {
            if (_open && value != _powerMonitorEnabled)
            {
                if (value)
                    Add(new PowerMonitorGroup(_settings));
                else
                    RemoveType<PowerMonitorGroup>();
            }

            _powerMonitorEnabled = value;
        }
    }

    public bool IsMemoryEnabled
    {
        get { return _memoryEnabled; }
        set
        {
            if (_open && value != _memoryEnabled)
            {
                if (value)
                    Add(new MemoryGroup(_settings));
                else
                    RemoveType<MemoryGroup>();
            }

            _memoryEnabled = value;
        }
    }

    public bool IsMotherboardEnabled
    {
        get { return _motherboardEnabled; }
        set
        {
            if (_open && value != _motherboardEnabled)
            {
                if (value)
                    Add(new MotherboardGroup(_smbios, _settings));
                else
                    RemoveType<MotherboardGroup>();
            }

            _motherboardEnabled = value;
        }
    }

    public bool IsNetworkEnabled
    {
        get { return _networkEnabled; }
        set
        {
            if (_open && value != _networkEnabled)
            {
                if (value)
                    Add(new NetworkGroup(_settings));
                else
                    RemoveType<NetworkGroup>();
            }

            _networkEnabled = value;
        }
    }

    public bool IsPsuEnabled
    {
        get { return _psuEnabled; }
        set
        {
            if (_open && value != _psuEnabled)
            {
                if (value)
                {
                    Add(new CorsairPsuGroup(_settings));
                    Add(new MsiPsuGroup(_settings));
                }
                else
                {
                    RemoveType<CorsairPsuGroup>();
                    RemoveType<MsiPsuGroup>();
                }
            }

            _psuEnabled = value;
        }
    }

    public bool IsStorageEnabled
    {
        get { return _storageEnabled; }
        set
        {
            if (_open && value != _storageEnabled)
            {
                if (value)
                    Add(new StorageGroup(_settings));
                else
                    RemoveType<StorageGroup>();
            }

            _storageEnabled = value;
        }
    }

    public SMBios SMBios
    {
        get
        {
            if (!_open)
                throw new InvalidOperationException("SMBIOS cannot be accessed before opening.");

            return _smbios;
        }
    }

    public string GetReport()
    {
        lock (_lock)
        {
            using StringWriter w = new(CultureInfo.InvariantCulture);

            w.WriteLine();
            w.WriteLine(nameof(XiaobaiHardwareMonitor) + " Report");
            w.WriteLine();

            Version version = typeof(Computer).Assembly.GetName().Version;

            NewSection(w);
            w.Write("Version: ");
            w.WriteLine(version.ToString());
            w.WriteLine();

            NewSection(w);
            w.Write("Common Language Runtime: ");
            w.WriteLine(Environment.Version.ToString());
            w.Write("Operating System: ");
            w.WriteLine(Environment.OSVersion.ToString());
            w.Write("Process Type: ");
            w.WriteLine(IntPtr.Size == 4 ? "32-Bit" : "64-Bit");
            w.WriteLine();

            NewSection(w);
            w.WriteLine("Sensors");
            w.WriteLine();

            foreach (IGroup group in _groups)
            {
                foreach (IHardware hardware in group.Hardware)
                    ReportHardwareSensorTree(hardware, w, string.Empty);
            }

            w.WriteLine();

            NewSection(w);
            w.WriteLine("Parameters");
            w.WriteLine();

            foreach (IGroup group in _groups)
            {
                foreach (IHardware hardware in group.Hardware)
                    ReportHardwareParameterTree(hardware, w, string.Empty);
            }

            w.WriteLine();

            foreach (IGroup group in _groups)
            {
                string report = group.GetReport();
                if (!string.IsNullOrEmpty(report))
                {
                    NewSection(w);
                    w.Write(report);
                }

                foreach (IHardware hardware in group.Hardware)
                    ReportHardware(hardware, w);
            }

            return w.ToString();
        }
    }

    public void Accept(IVisitor visitor)
    {
        if (visitor == null)
            throw new ArgumentNullException(nameof(visitor));

        visitor.VisitComputer(this);
    }

    public void Traverse(IVisitor visitor)
    {
        lock (_lock)
        {
            
            for (int i = 0; i < _groups.Count; i++)
            {
                IGroup group = _groups[i];

                for (int j = 0; j < group.Hardware.Count; j++)
                    group.Hardware[j].Accept(visitor);
            }
        }
    }

    private void HardwareAddedEvent(IHardware hardware)
    {
        HardwareAdded?.Invoke(hardware);
    }

    private void HardwareRemovedEvent(IHardware hardware)
    {
        HardwareRemoved?.Invoke(hardware);
    }

    private void Add(IGroup group)
    {
        if (group == null)
            return;

        lock (_lock)
        {
            if (_groups.Contains(group))
                return;

            _groups.Add(group);

            if (group is IHardwareChanged hardwareChanged)
            {
                hardwareChanged.HardwareAdded += HardwareAddedEvent;
                hardwareChanged.HardwareRemoved += HardwareRemovedEvent;
            }
        }

        if (HardwareAdded != null)
        {
            foreach (IHardware hardware in group.Hardware)
                HardwareAdded(hardware);
        }
    }

    private void Remove(IGroup group)
    {
        lock (_lock)
        {
            if (!_groups.Contains(group))
                return;

            _groups.Remove(group);

            if (group is IHardwareChanged hardwareChanged)
            {
                hardwareChanged.HardwareAdded -= HardwareAddedEvent;
                hardwareChanged.HardwareRemoved -= HardwareRemovedEvent;
            }
        }

        if (HardwareRemoved != null)
        {
            foreach (IHardware hardware in group.Hardware)
                HardwareRemoved(hardware);
        }

        group.Close();
    }

    private void RemoveType<T>() where T : IGroup
    {
        List<T> list = [];

        lock (_lock)
        {
            foreach (IGroup group in _groups)
            {
                if (group is T t)
                    list.Add(t);
            }
        }

        foreach (T group in list)
            Remove(group);
    }

    public void Open()
    {
        if (_open)
            return;

        _smbios = new SMBios();

        if (Software.OperatingSystem.IsWindows8OrGreater)
            Mutexes.Open();

        OpCode.Open();

        AddGroups();

        _open = true;
    }

    private void AddGroups()
    {
        if (_motherboardEnabled)
            Add(new MotherboardGroup(_smbios, _settings));

        if (_cpuEnabled)
            Add(new CpuGroup(_settings));

        if (_memoryEnabled)
            Add(new MemoryGroup(_settings));

        if (_gpuEnabled)
        {
            Add(new AmdGpuGroup(_settings));
            Add(new NvidiaGroup(_settings));

            if (_cpuEnabled)
                Add(new IntelGpuGroup(GetIntelCpus(), _settings));
        }

        if (_powerMonitorEnabled)
            Add(new PowerMonitorGroup(_settings));

        if (_controllerEnabled)
        {
            Add(new TBalancerGroup(_settings));
            Add(new HeatmasterGroup(_settings));
            Add(new AquaComputerGroup(_settings));
            Add(new AeroCoolGroup(_settings));
            Add(new NzxtGroup(_settings));
            Add(new RazerGroup(_settings));
            Add(new ArcticGroup(_settings));
            Add(new MsiGroup(_settings));
        }

        if (_storageEnabled)
            Add(new StorageGroup(_settings));

        if (_networkEnabled)
            Add(new NetworkGroup(_settings));

        if (_psuEnabled)
        {
            Add(new CorsairPsuGroup(_settings));
            Add(new MsiPsuGroup(_settings));
        }

        if (_batteryEnabled)
            Add(new BatteryGroup(_settings));
    }

    private static void NewSection(TextWriter writer)
    {
        for (int i = 0; i < 8; i++)
            writer.Write("----------");

        writer.WriteLine();
        writer.WriteLine();
    }

    private static int CompareSensor(ISensor a, ISensor b)
    {
        int c = a.SensorType.CompareTo(b.SensorType);
        if (c == 0)
            return a.Index.CompareTo(b.Index);

        return c;
    }

    private static void ReportHardwareSensorTree(IHardware hardware, TextWriter w, string space)
    {
        w.WriteLine("{0}|", space);
        w.WriteLine("{0}+- {1} ({2})", space, hardware.Name, hardware.Identifier);

        ISensor[] sensors = hardware.Sensors;
        Array.Sort(sensors, CompareSensor);

        foreach (ISensor sensor in sensors)
            w.WriteLine("{0}|  +- {1,-14} : {2,8:G6} {3,8:G6} {4,8:G6} ({5})", space, sensor.Name, sensor.Value, sensor.Min, sensor.Max, sensor.Identifier);

        foreach (IHardware subHardware in hardware.SubHardware)
            ReportHardwareSensorTree(subHardware, w, "|  ");
    }

    private static void ReportHardwareParameterTree(IHardware hardware, TextWriter w, string space)
    {
        w.WriteLine("{0}|", space);
        w.WriteLine("{0}+- {1} ({2})", space, hardware.Name, hardware.Identifier);

        ISensor[] sensors = hardware.Sensors;
        Array.Sort(sensors, CompareSensor);

        foreach (ISensor sensor in sensors)
        {
            string innerSpace = space + "|  ";
            if (sensor.Parameters.Count > 0)
            {
                w.WriteLine("{0}|", innerSpace);
                w.WriteLine("{0}+- {1} ({2})", innerSpace, sensor.Name, sensor.Identifier);

                foreach (IParameter parameter in sensor.Parameters)
                {
                    string innerInnerSpace = innerSpace + "|  ";
                    w.WriteLine("{0}+- {1} : {2}", innerInnerSpace, parameter.Name, string.Format(CultureInfo.InvariantCulture, "{0} : {1}", parameter.DefaultValue, parameter.Value));
                }
            }
        }

        foreach (IHardware subHardware in hardware.SubHardware)
            ReportHardwareParameterTree(subHardware, w, "|  ");
    }

    private static void ReportHardware(IHardware hardware, TextWriter w)
    {
        string hardwareReport = hardware.GetReport();
        if (!string.IsNullOrEmpty(hardwareReport))
        {
            NewSection(w);
            w.Write(hardwareReport);
        }

        foreach (IHardware subHardware in hardware.SubHardware)
            ReportHardware(subHardware, w);
    }

    public void Close()
    {
        if (!_open)
            return;

        lock (_lock)
        {
            while (_groups.Count > 0)
            {
                IGroup group = _groups[_groups.Count - 1];
                Remove(group);
            }
        }

        OpCode.Close();
        Mutexes.Close();

        _smbios = null;
        _open = false;
    }

    public void Reset()
    {
        if (!_open)
            return;

        RemoveGroups();
        AddGroups();
    }

    private void RemoveGroups()
    {
        lock (_lock)
        {
            while (_groups.Count > 0)
            {
                IGroup group = _groups[_groups.Count - 1];
                Remove(group);
            }
        }
    }

    private List<IntelCpu> GetIntelCpus()
    {
        
        lock (_lock)
        {
            IGroup cpuGroup = _groups.Find(x => x is CpuGroup) ?? new CpuGroup(_settings);
            return cpuGroup.Hardware.Select(x => x as IntelCpu).ToList();
        }
    }

    private class Settings : ISettings
    {
        public bool Contains(string name)
        {
            return false;
        }

        public void SetValue(string name, string value)
        { }

        public string GetValue(string name, string value)
        {
            return value;
        }

        public void Remove(string name)
        { }
    }
}
