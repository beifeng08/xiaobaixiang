﻿// Copyright (c) 2026 beifeng08
// Licensed under the MIT License. See LICENSE in the project root.

using System;
using System.Linq;
using System.Threading;
using HidSharp;

namespace XiaobaiHardwareMonitor.Hardware.Controller.Arctic;

internal class ArcticFanController : Hardware
{
    private const int CHANNEL_COUNT = 10;
    private const int PACKET_SIZE = 32;
    private const int CONTROL_VALUE_MIN = 0;
    private const int CONTROL_VALUE_MAX = 100;
    private const int CONTROL_RESET_VALUE = 30;
    private const int TIMEOUT_MS = 1000;

    private HidStream _hidStream;
    private readonly object _hidLock = new();
    private readonly object _controlLock = new();
    private readonly Thread _thread;
    private readonly float[] _requestedFanSpeedsPercent = new float[CHANNEL_COUNT];
    private readonly float[] _currentFanRpms = new float[CHANNEL_COUNT];
    private readonly float[] _currentDevicePwmValues = new float[CHANNEL_COUNT]; 
    private bool _sendPwmRequested;
    private bool _pwmValuesInitialized = false; 
    private readonly System.Collections.Generic.List<Sensor> _rpmSensors = new();
    private readonly System.Collections.Generic.List<Sensor> _controlSensors = new();

    public ArcticFanController(HidDevice dev, ISettings settings) : base("ARCTIC Fan Controller", new Identifier(dev), settings)
    {
        if (dev.TryOpen(out HidStream hidStream))
        {
            
            for (int i = 1; i <= CHANNEL_COUNT; i++)
            {
                var fanSensor = new Sensor($"Fan #{i}", i, SensorType.Fan, this, settings);
                ActivateSensor(fanSensor);
                _rpmSensors.Add(fanSensor);
            }

            for (int i = 1; i <= CHANNEL_COUNT; i++)
            {
                var controlSensor = new Sensor($"Control #{i}", i, SensorType.Control, this, settings);
                Control control = new(controlSensor, settings, CONTROL_VALUE_MIN, CONTROL_VALUE_MAX);
                control.ControlModeChanged += Control_ControlModeChanged;
                control.SoftwareControlValueChanged += Control_SoftwareControlValueChanged;

                controlSensor.Control = control;
                ActivateSensor(controlSensor); 
                _controlSensors.Add(controlSensor);
            }

            _hidStream = hidStream;
            _hidStream.ReadTimeout = TIMEOUT_MS;
            _hidStream.WriteTimeout = TIMEOUT_MS;

            _thread = new Thread(ThreadHidLoop);
            _thread.IsBackground = true; 
            _thread.Start(); 
        }
    }

    private void ThreadHidLoop()
    {
        while (_hidStream != null)
        {
            lock (_hidLock)
            {
                if (_hidStream == null) return;

                UpdateRpmAndPwmValues();
                SendPWMUpdateIfRequired();
            }

            Thread.Sleep(500);
        }
    }

    private void Control_SoftwareControlValueChanged(Control control)
    {
        
        lock (_controlLock)
        {
            var value = control.ControlMode switch
            {
                ControlMode.Software => Math.Max(Math.Min(control.SoftwareValue, CONTROL_VALUE_MAX), CONTROL_VALUE_MIN),
                _ => CONTROL_RESET_VALUE,
            };

            _requestedFanSpeedsPercent[control.Sensor.Index - 1] = value;
            _sendPwmRequested = true;
        }

        (control.Sensor as Sensor)?.Value = control.ControlMode == ControlMode.Software ? control.SoftwareValue : null;
    }

    private void Control_ControlModeChanged(Control control)
    {
        Control_SoftwareControlValueChanged(control);
    }

    public override HardwareType HardwareType { get; } = HardwareType.Cooler;

    public override void Update()
    {
        lock (_hidLock)
        {
            foreach (Sensor sensor in _rpmSensors)
            {
                sensor.Value = GetRPM(sensor.Index);
            }

            foreach (Sensor sensor in _controlSensors)
            {
                int idx = sensor.Index - 1;
                if (idx >= 0 && idx < CHANNEL_COUNT &&
                    
                    sensor.Control?.ControlMode != ControlMode.Software)
                {
                    
                    float displayValue = _pwmValuesInitialized ? _currentDevicePwmValues[idx] : _requestedFanSpeedsPercent[idx];
                    sensor.Value = displayValue;
                }

            }
        }
    }

    public override void Close()
    {
        lock (_hidLock)
        {
            try
            {
                lock (_controlLock)
                {
                    
                    for (int i = 0; i < CHANNEL_COUNT; i++)
                    {
                        _requestedFanSpeedsPercent[i] = CONTROL_RESET_VALUE;
                    }

                    _sendPwmRequested = true;
                }

                SendPWMUpdateIfRequired();

            }
            catch { }

            try
            {
                _hidStream?.Close();
                _hidStream?.Dispose();

            }
            catch { }
            
            finally
            {
                _hidStream = null;
            }
        }

        _thread?.Join(1000);

        base.Close();
    }

    private void UpdateRpmAndPwmValues()
    {
        if (_hidStream is null)
        {
            return;
        }

        if (_hidStream is null)
        {
            return;
        }

        try
        {
            
            byte[] response = null;
            int attempts = 0;
            const int maxAttempts = 3;

            while (attempts < maxAttempts)
            {
                try
                {
                    
                    var originalTimeout = _hidStream.ReadTimeout;
                    _hidStream.ReadTimeout = 200;

                    response = new byte[PACKET_SIZE];
                    int bytesRead = _hidStream.Read(response, 0, PACKET_SIZE);

                    _hidStream.ReadTimeout = originalTimeout;

                    if (bytesRead >= PACKET_SIZE && response[0] == 0x01)
                    {
                        
                        break;
                    }
                }
                catch (TimeoutException)
                {
                    
                }
                catch
                {
                    
                }

                attempts++;
                if (attempts < maxAttempts) Thread.Sleep(50);
            }

            ProcessResponse(response);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"RPM update failed: {ex.Message}");
        }
    }

    private void ProcessResponse(byte[] response)
    {
        if (response == null || response.Length < PACKET_SIZE || response[0] != 0x01)
        {
            return;
        }

        for (int i = 0; i < CHANNEL_COUNT; i++)
        {
            if (1 + i < response.Length)
            {
                _currentDevicePwmValues[i] = response[1 + i];
            }
        }

        if (!_pwmValuesInitialized)
        {
            lock (_controlLock)
            {
                for (int i = 0; i < CHANNEL_COUNT; i++)
                {
                    _requestedFanSpeedsPercent[i] = _currentDevicePwmValues[i];
                }
                _pwmValuesInitialized = true;
            }
        }

        for (int i = 0; i < CHANNEL_COUNT; i++)
        {
            int rpmIndex = 11 + i * 2;
            if (rpmIndex + 1 < response.Length)
            {
                int rpmLow = response[rpmIndex];
                int rpmHigh = response[rpmIndex + 1];
                _currentFanRpms[i] = rpmLow | (rpmHigh << 8);
            }
        }
    }

    private void SendPWMUpdateIfRequired()
    {
        float[] values = null;
        lock (_controlLock)
        {
            if (!_sendPwmRequested)
            {
                return;
            }

            _sendPwmRequested = false;
            values = _requestedFanSpeedsPercent.ToArray();
        }

        try
        {
            
            byte[] pwmPacket = new byte[PACKET_SIZE];
            pwmPacket[0] = 0x01; 

            for (int i = 0; i < CHANNEL_COUNT; i++)
            {
                pwmPacket[1 + i] = (byte)Math.Round(values[i]);
            }
            
            _hidStream.Write(pwmPacket);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"PWM update failed: {ex.Message}");
        }
    }

    private float GetRPM(int fanIndex)
    {
        if (fanIndex < 1 || fanIndex > CHANNEL_COUNT)
        {
            return 0;
        }

        return _currentFanRpms[fanIndex - 1];
    }
}
